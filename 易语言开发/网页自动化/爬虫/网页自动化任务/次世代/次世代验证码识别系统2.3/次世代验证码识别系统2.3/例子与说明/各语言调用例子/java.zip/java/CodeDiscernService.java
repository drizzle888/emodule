package org.com.skycc.bean;
import com.sun.jna.Library;
import com.sun.jna.Native;
public class CodeDiscernService {
	public interface CLibrary extends Library{
		CLibrary INSTANCE = (CLibrary)Native.loadLibrary("AntiVC_new",CLibrary.class);
				public int LoadCdsFromBuffer(int FileBuffer , int FileBufLen, String Password);
				//public int GetVcodeFromBuffer();
				public int LoadCdsFromFile(String FilePath , String Password);
			    //public int GetVcodeFromURL(int CdsFileIndex , String ImgURL,byte[] Vcode );
				public Boolean SetTimeOut(int CdsFileIndex , int ttime);
		        public int GetVcodeFromFile( int CdsFileIndex, String FilePath,byte[] Vcode);
		        public int GetVcodeFromBuffer(int CdsFileIndex ,int ImgBuffer , int ImgBufLen, Byte[] Vcode );
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
