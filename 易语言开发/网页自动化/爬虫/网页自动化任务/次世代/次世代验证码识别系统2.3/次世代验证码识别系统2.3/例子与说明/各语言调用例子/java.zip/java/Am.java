package org.com.skycc.test;
 
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.xml.bind.annotation.adapters.HexBinaryAdapter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse; 
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.log4j.Logger;
import org.apache.tools.ant.types.resources.selectors.Date;
import org.com.skycc.bean.CodeDiscernService.CLibrary;
import org.com.skycc.bean.statics.System_Constants;
import org.com.skycc.common.util.WebUtils;


public class Am { 
	private static int abc;
	static{
		abc= CLibrary.INSTANCE.LoadCdsFromFile("C:/a/x.cds","dooommmy3y");
		Boolean b=CLibrary.INSTANCE.SetTimeOut(abc, 5000); 
	}
	 
   /**
	 * @param args
 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {   
		
		String creakNum="";
		byte[] result = new byte[5];
		CLibrary.INSTANCE.GetVcodeFromFile(abc,"c:\\a\\testimage\\10.bmp",result);
		for(int i=0;i<result.length;i++)
	    {
		  String t=String.valueOf((char)result[i]);
		  creakNum+=t;
		  creakNum=creakNum.trim();
	    }
		System.out.println(creakNum);
		
	}

}
